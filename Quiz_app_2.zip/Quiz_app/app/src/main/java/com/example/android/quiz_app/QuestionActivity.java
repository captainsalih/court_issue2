package com.example.android.quiz_app;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.RadioButton;

import java.util.ArrayList;

public class QuestionActivity extends AppCompatActivity {

    RadioButton button1;
    RadioButton button2;
    RadioButton button3;
    RadioButton button4;

 //   int selected_position = -1;
private static final  String TAG = "Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question_list);

        final ArrayList<List> list = new ArrayList<List>();
        list.add(new List("Question 1", R.drawable.pic2, "Known as one of the father of science," +
                " developed the theory of relativity, he represents the genius, everyone know him.",
                "Albert Einstein", "Galileo Galilei", "Archimedes", "I Dont Know"));
        list.add(new List("Question 2", R.drawable.pic3, "She is the mother of science, the only one" +
               " human in history who got two nobel prize in two different fields Chemistry" +
                " and Physics.", "Maria Theresa", "Raisa Adriana", "Marie Curie", "I Dont Know"));
        list.add(new List("Question 3", R.drawable.pic4, "His name is settled as one of universal" +
                " constant, his research in black body radiation led to the origin of quantum theory.",
                "Isaac Newton", "Max Planck", "Ludwig Boltzman", "Amedeo Avogadro"));
        //list.add(new List("Question 4", R.drawable.pic5, "An Austrian physicists who invented the " +
        //        "fundamental function on quantum theory called wave function, die/alive cat in the " +
        //        "box is one of his famous paradox.", "Stephen Hawking", "Werner Heisenberg",
        //        "Erich Hückel", "Erwin Schrödinger "));
        //list.add(new List("Question 5", R.drawable.pic6, "Known as the great explainer, his diagram " +
         //       "simplify the mathematical expression of subatomic particles behavior.",
          //      "Neils Bohr ", "Thomas Alva Edison", "Richard Feynman", "James Watt "));
       // list.add(new List("Question 6", R.drawable.pic7, "A German physicists who establish " +
         //       "the uncertainty principle one of the fundamental concept in quantum theory.",
           //     "Werner Heisenberg ", "Wolfgang Pauli", "Louis de Broglie", "P.M Dirac "));
       // list.add(new List("Question 7", R.drawable.pic8, "He proposed the modern atomic model and " +
         //       "the mentor of Werner Heisenberg.",
           //     "Werner Heisenberg ", "Neils Bohr", "Ernest Rutherford", "J. J. Thomson"));
       // list.add(new List("Question 8", R.drawable.pic9, "He is the key figure in the scientific " +
         //       "revolution, calculus and the law of mechanics are short of his contributions to the " +
           //     "society, one of his great idea comes from the apple.",
             //   "Steve Jobs ", "Galileo Galilei", "Johannes Kepler", "Isaac Newton"));
        //list.add(new List("Question 9", R.drawable.pic10, "Because of him you now can use your mobile " +
          //      "phone, he is the inventor of wireless and want to give free energy for the world.",
            //    "Elon Musk ", "James Watt", "Nikola Tesla", "Thomas Alva Edison"));
        list.add(new List("Question 10", R.drawable.pic11, "His invention is the main reason of " +
                "industrial revolution.",
                "James Watt ", "Archimedes", "Daniel Bernoulli", "Ernst Mach", "SUBMIT"));

        //list.add(new List("Question 3", R.drawable.pic6,
        //        "A Theoretical Chemistry student from Moluccas, Invented nothing, Always fail on The Organic Chemistry class",
        //       "Albert Einstein","Nikola Tesla","Erwin Schrödinger",
        //       "I Dont Know", "SUBMIT"));

        // Find a reference to the {@link List} in the layout
        final ListView listView = (ListView) findViewById(R.id.Question_list);

        // Create a new adapter that takes the list of list as input
         final Adapter adapter = new Adapter(this, list);

    }




}
