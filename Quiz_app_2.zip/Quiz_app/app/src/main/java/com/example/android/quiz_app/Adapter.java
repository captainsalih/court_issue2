package com.example.android.quiz_app;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by mus on 7/4/17.
 */

public class Adapter extends ArrayAdapter<List> {




    /**
     constructor to to populate the listview
     */

    public Adapter(Activity context, ArrayList<List> list) {
        // initialize the ArrayAdapter's internal storage for the context and the list.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value.
        super(context, 0, list);
    }



    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View ViewHolder = convertView;
        if (ViewHolder == null) {
            ViewHolder = LayoutInflater.from(getContext()).inflate(
                    R.layout.question_template,parent,false);
        }


        // Get the object located at this position in the list
        final List currentList = getItem(position);

        //Get and set the object for Head/Question Head
        TextView headView = (TextView)ViewHolder.findViewById(R.id.head);
        headView.setText(currentList.getHead());

        //Get and set the object for the image
        ImageView imageView = (ImageView) ViewHolder.findViewById(R.id.image);
        imageView.setImageResource(currentList.getImage());

        //Get and set the object for the Question
        TextView questionView = (TextView) ViewHolder.findViewById(R.id.thequestion);
        questionView.setText(currentList.getQuestion());



        //EXPERIMENTAL SECTION

        //Get the radio button A
        final RadioButton choiceaView = (RadioButton) ViewHolder.findViewById(R.id.answer1);
        //Set the radio button for the choice A
        choiceaView.setText(currentList.getChoiceA());


       //Get the radio button B
       final RadioButton choicebView = (RadioButton) ViewHolder.findViewById(R.id.answer2);
        //Set the radio button for the choice B
        choicebView.setText(currentList.getChoiceB());



        //Get the radio button C
         final RadioButton choicecView = (RadioButton) ViewHolder.findViewById(R.id.answer3);
        //Set the radio button for the choice C
        choicecView.setText(currentList.getChoiceC());




        //Get the radio button D
       final RadioButton choicedView = (RadioButton) ViewHolder.findViewById(R.id.answer4);
        //Set the radio button for the choice D
        choicedView.setText(currentList.getChoiceD());



      //EXPERIMENTAL SECTION




        //Get the object for the SUBMIT view
        final TextView nextView = (TextView) ViewHolder.findViewById(R.id.submit);
        //Check if the object has view or not
        if (currentList.hasView()){

            //Set the view with visibility
            nextView.setText(currentList.getNext());
            nextView.setVisibility(View.VISIBLE);

            //Apply the clickListener
            nextView.setOnClickListener(new View.OnClickListener() {
              @Override
               public void onClick(View v) {
               Toast.makeText(getContext(),"the message",Toast.LENGTH_SHORT).show();
                }
           });
        }
        else {
            //hide the view
            nextView.setVisibility(View.GONE);
        }

        // Return the whole list item layout & show it to the Listview
        return ViewHolder;
    }
}

